/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author MP2-4
 */

public class SessionBean {
    private int session_id;
    private String student_name;
    private String branch_location;
    private String session_type;
    private String status;

    
// Constructor Kosong (Wajib untuk JavaBean)
public SessionBean() {
}

// Constructor dengan ID (Untuk Update & Delete)
public SessionBean(int session_id, String student_name, String branch_location, String session_type, String status) {
    this.session_id = session_id;
    this.student_name = student_name;
    this.branch_location = branch_location;
    this.session_type = session_type;
    this.status = status;
}

// Constructor tanpa ID (Untuk Insert)
public SessionBean(String student_name, String branch_location, String session_type, String status) {
    this.student_name = student_name;
    this.branch_location = branch_location;
    this.session_type = session_type;
    this.status = status;
}

// Getter dan Setter
public int getId() {
    return session_id;
}
public void setId(int id) {
    this.session_id = session_id;
}
public String getstudent_name() {
    return student_name;
}
public void setstudent_name(String student_name) {
    this.student_name = student_name;
}
public String getbranch_location() {
    return branch_location;
}
public void setbranch_location(String branch_location) {
    this.branch_location = branch_location;
}
public String getsession_type() {
    return session_type;
}
public void setsession_type(String session_type) {
    this.session_type = session_type;
}
public String getstatus() {
    return status;
}
public void setstatus(String status) {
    this.status ="Booking";
}

public String g() {
    return student_name;
}
public void status(String status) {
    this.status = "Booking";
}
}