/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
import com.mysql.cj.DataStoreMetadata;
import com.mysql.cj.MessageBuilder;
import com.mysql.cj.Session;
import com.mysql.cj.conf.HostInfo;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.log.Log;
import com.mysql.cj.log.ProfilerEventHandler;
import com.mysql.cj.protocol.Message;
import com.mysql.cj.protocol.ServerSession;
import com.mysql.cj.telemetry.TelemetryHandler;
import java.io.IOException;
import java.net.SocketAddress;
import java.util.concurrent.locks.Lock;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 *
 * @author MP2-4
 */

public class BookSessionServlet extends HttpServlet {
    private SessionDAO sessionDAO;
    
    public void init() {
        sessionDAO = new SessionDAO();
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse
            response) throws ServletException, IOException {
        String student_name = request.getParameter("student_name");
        String branch_location = request.getParameter("branch_location");
        String session_type = request.getParameter("session_type");

SessionBean newSessionBean = new SessionBean(student_name, branch_location, session_type) {
    
    SessionBean.insertSessionbean(newSessionBean); // Panggil DAO, bukan JDBC

response.sendRedirect("ScheduleServlet");
}
        }
}

