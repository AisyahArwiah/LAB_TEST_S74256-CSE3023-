<%-- 
    Document   : footer
    Created on : 16 Jun 2026, 2:22:54 PM
    Author     : MP2-4
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Drivesmart Integrated Academy</title>
    </head>
    <footer style="text-align: center; padding: 20px; font-size: 12px; border-top: 1px solid #ccc; margin-top: 20px ">
        &copy; 2026 Drivesmart Academy
    </footer>    
    </body>
</html>
